﻿Imports MySql.Data.MySqlClient

Public Class MenuUser

    Private Sub Pesan_Click(sender As Object, e As EventArgs) Handles Pesan.Click
        PesanTiket.statuss.Text = "Belum Bayar"
        PesanTiket.Show()
        Me.Hide()
    End Sub

    'Private Sub Riwayat_Click(sender As Object, e As EventArgs)
    'RiwayatPesanan.Show()
    'Me.Close()
    'End Sub

    Private Sub Logout_Click(sender As Object, e As EventArgs) Handles Logout.Click
        MenuAwal.Show()
        Me.Close()
    End Sub

    Private Sub MenuUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class