-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Bulan Mei 2023 pada 09.05
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_konser`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbadmin`
--

CREATE TABLE `tbadmin` (
  `id_admin` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbadmin`
--

INSERT INTO `tbadmin` (`id_admin`, `username`, `password`) VALUES
(1, 'jennie', 'jennie123'),
(3, 'sarahsyifa', 'sarah123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbguest`
--

CREATE TABLE `tbguest` (
  `id_guest` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbguest`
--

INSERT INTO `tbguest` (`id_guest`, `nama`) VALUES
(1, 'NEW JEANS'),
(2, 'BTS'),
(3, 'TULUS');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbpesanan`
--

CREATE TABLE `tbpesanan` (
  `id_pesanan` int(10) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `noktp` int(16) NOT NULL,
  `email` varchar(20) NOT NULL,
  `nohp` int(13) NOT NULL,
  `guest` varchar(20) NOT NULL,
  `jenis` varchar(10) NOT NULL,
  `jumlah` int(2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbpesanan`
--

INSERT INTO `tbpesanan` (`id_pesanan`, `nama`, `noktp`, `email`, `nohp`, `guest`, `jenis`, `jumlah`, `status`) VALUES
(1, 'wee', 0, '1', 2, 'NEW JEANS', 'reguler', 2, 'Belum Baya'),
(2, 'saw', 12, '12', 12, 'NEW JEANS', 'reguler', 2, 'Sudah Baya'),
(3, 'baru', 123456, 'sarah@gmail', 89999, 'BLACKPINK', 'vip', 3, 'Belum Baya'),
(4, 'sarah', 123, 'sarah@gmail', 895, 'TULUS', 'vip', 1, 'Belum Baya');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbregis`
--

CREATE TABLE `tbregis` (
  `id_regis` int(11) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbregis`
--

INSERT INTO `tbregis` (`id_regis`, `nama_lengkap`, `username`, `password`) VALUES
(1, ' Mirabella Arabella Sitamirra ', ' mirabellasyu ', ' mirabellasyu '),
(2, ' Fatimah Khairunnissa Adzana ', ' fatimahtunnissa ', ' fatimahtunnisa10 '),
(3, ' Sarah Syifani ', ' sarahsyifa ', ' sarah123 ');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbadmin`
--
ALTER TABLE `tbadmin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `tbguest`
--
ALTER TABLE `tbguest`
  ADD PRIMARY KEY (`id_guest`);

--
-- Indeks untuk tabel `tbpesanan`
--
ALTER TABLE `tbpesanan`
  ADD PRIMARY KEY (`id_pesanan`);

--
-- Indeks untuk tabel `tbregis`
--
ALTER TABLE `tbregis`
  ADD PRIMARY KEY (`id_regis`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbadmin`
--
ALTER TABLE `tbadmin`
  MODIFY `id_admin` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbguest`
--
ALTER TABLE `tbguest`
  MODIFY `id_guest` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbpesanan`
--
ALTER TABLE `tbpesanan`
  MODIFY `id_pesanan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbregis`
--
ALTER TABLE `tbregis`
  MODIFY `id_regis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
