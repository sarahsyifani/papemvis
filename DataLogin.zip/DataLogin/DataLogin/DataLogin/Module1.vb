﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Module Module1
    Public Conn As New MySqlConnection
    Public Da As MySqlDataAdapter
    Public Ds As DataSet
    Public Rd As MySqlDataReader
    Public Cmd As MySqlCommand
    Public DT As DataTable
    Public Str As String
    Sub Koneksi()
        Try
            Dim Str As String = "server=localhost;userid=root;password=;database=database_konser"
            Conn = New MySQLConnection(Str)
            If Conn.State = ConnectionState.Closed Then
                Conn.Open()
            End If
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message, "Error!", MessageBoxButtons.OK,
            MessageBoxIcon.Error)
        End Try
    End Sub
End Module