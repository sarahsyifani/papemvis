﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MenuUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Logout = New System.Windows.Forms.Button()
        Me.Pesan = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Logout
        '
        Me.Logout.BackColor = System.Drawing.Color.BurlyWood
        Me.Logout.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Logout.Location = New System.Drawing.Point(403, 215)
        Me.Logout.Name = "Logout"
        Me.Logout.Size = New System.Drawing.Size(100, 55)
        Me.Logout.TabIndex = 3
        Me.Logout.Text = "Logout"
        Me.Logout.UseVisualStyleBackColor = False
        '
        'Pesan
        '
        Me.Pesan.BackColor = System.Drawing.Color.BurlyWood
        Me.Pesan.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pesan.Location = New System.Drawing.Point(275, 215)
        Me.Pesan.Name = "Pesan"
        Me.Pesan.Size = New System.Drawing.Size(100, 55)
        Me.Pesan.TabIndex = 2
        Me.Pesan.Text = "Pesan Tiket"
        Me.Pesan.UseVisualStyleBackColor = False
        '
        'MenuUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.menu
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(764, 444)
        Me.Controls.Add(Me.Logout)
        Me.Controls.Add(Me.Pesan)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MenuUser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MenuUser"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Logout As Button
    Friend WithEvents Pesan As Button
End Class
