﻿Imports System.Data.SqlClient
Imports Microsoft.Win32
Imports MySql.Data.MySqlClient

Public Class DataLogin
    'Sub textId()
    'Call Koneksi()
    'Cmd = New MySqlCommand("select id_regis from tbregis where username='" & txtboxUsername.Text & "'", Conn)
    'Rd = Cmd.ExecuteReader
    'Rd.Read()
    'On Error GoTo Err
    'If Rd.HasRows Then
    'MenuUser.lbId.Text = Val(Rd.Item("id_regis"))
    'If
    'Rd.Close()
    'Exit Sub
    'Err:
    'PesanTiket.tbId.Text = "1"
    'End Sub

    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Sistem Penjualan Tiket Konser"
        'Panggil Koneksi
        Call Koneksi()
        'Call textId()
    End Sub

    Private Sub checkboxTampil_CheckedChanged_1(sender As Object, e As EventArgs) Handles checkboxTampil.CheckedChanged
        'Tampilkan Password yang tersembunyi
        'Show Password
        If txtboxPassword.UseSystemPasswordChar = True Then
            'Hide
            txtboxPassword.UseSystemPasswordChar = False
        Else
            'Show
            txtboxPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnLoginFirst_Click_1(sender As Object, e As EventArgs) Handles btnLoginFirst.Click
        'Sistem Login Setelah Register
        Cmd = New MySqlCommand
        Cmd.Connection = Conn
        Str = "SELECT * FROM tbregis WHERE username = ' " & txtboxUsername.Text & " ' AND password = ' " & txtboxPassword.Text & " '  "
        Da = New MySqlDataAdapter(Str, Conn)
        DT = New DataTable()
        'Data Table System
        Try
            Da.Fill(DT)
            'Sistem
            If DT.Rows.Count <= 0 Then
                MsgBox("Sorry! Login Anda Gagal!", vbInformation)
            Else
                PesanTiket.username.Text = txtboxUsername.Text
                MenuUser.Show()
                Me.Close()
            End If
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'Ubah
        'RiwayatPesanan.Label2.Text = txtboxUsername.Text
        'Konfirmasi.labelUsername.Text = txtboxUsername.Text
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Menggunakan Fungsi Clear untuk menghapus
        txtboxUsername.Clear()
        txtboxPassword.Clear()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        MenuAwal.Show()
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Register.Show()
        Me.Close()
    End Sub
End Class