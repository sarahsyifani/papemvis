﻿Public Class MenuAdmin
    Private Sub pesanan_Click(sender As Object, e As EventArgs) Handles pesanan.Click
        DataPesanan.Show()
        Me.Hide()
    End Sub

    Private Sub guest_Click(sender As Object, e As EventArgs) Handles guest.Click
        DataGuest.Show()
        Me.Hide()
    End Sub

    Private Sub Logout_Click(sender As Object, e As EventArgs) Handles Logout.Click
        MenuAwal.Show()
        Me.Hide()
    End Sub
End Class