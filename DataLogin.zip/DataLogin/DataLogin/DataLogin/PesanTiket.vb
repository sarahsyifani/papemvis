﻿Imports System.Runtime.InteropServices.ComTypes
Imports MySql.Data.MySqlClient
Imports System.Data.Odbc

Public Class PesanTiket
    Sub KondisiAwal()
        'id_pesanan.Clear()
        nama.Clear()
        noktp.Clear()
        email.Clear()
        nohp.Clear()
        artis.Text = ""
        jenis.Text = ""
        jumlah.Text = ""
        statuss.Text = ""
        btnPesan.Text = "Pesan Tiket"
        Call Koneksi()
        Call Pesan()
    End Sub
    Sub Isi()
        id_pesanan.Clear()
        id_pesanan.Focus()
        nama.Clear()
        nama.Focus()
        noktp.Clear()
        noktp.Focus()
        email.Clear()
        email.Focus()
        nohp.Clear()
        nohp.Focus()
        'artis.Clear()
        artis.Focus()
        'jenis.Clear()
        jenis.Focus()
        'jumlah.Clear()
        jumlah.Focus()
        'statuss.Clear()
        statuss.Focus()
    End Sub
    Sub txId()

        Call Koneksi()
        Cmd = New MySqlCommand("select id_regis from tbregis where username like '%" & username.Text & "%'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        On Error GoTo Err
        If Rd.HasRows Then
            id_user.Text = Format(Val(Rd.Item(0)), "0")
        End If
        Exit Sub
Err:
        id_user.Text = Format(Val(Rd.Item(0)) + 1, "0")
    End Sub
    Sub AutoNumber()
        Call Koneksi()
        Cmd = New MySqlCommand("select max(id_pesanan) from tbpesanan", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        On Error GoTo Err
        If Rd.HasRows Then
            id_pesanan.Text = Format(Val(Rd.Item(0)) + 1, "0")
        End If
        Exit Sub
Err:
        id_pesanan.Text = "1"
    End Sub

    Sub Pesan()
        Da = New MySqlDataAdapter("select * from tbpesanan", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbpesanan")
        dgv1.DataSource = Ds.Tables("tbpesanan")
        dgv1.Refresh()
    End Sub

    Sub AturGrid()
        dgv1.Columns(0).Width = 60
        dgv1.Columns(1).Width = 100
        dgv1.Columns(2).Width = 100
        dgv1.Columns(3).Width = 100
        dgv1.Columns(4).Width = 100
        dgv1.Columns(5).Width = 100
        dgv1.Columns(6).Width = 100
        dgv1.Columns(7).Width = 100
        dgv1.Columns(8).Width = 100
        dgv1.Columns(8).Width = 100

        dgv1.Columns(0).HeaderText = "ID PESANAN"
        dgv1.Columns(1).HeaderText = "NAMA"
        dgv1.Columns(2).HeaderText = "NO KTP"
        dgv1.Columns(3).HeaderText = "EMAIL"
        dgv1.Columns(4).HeaderText = "NO HP"
        dgv1.Columns(5).HeaderText = "GUEST STAR"
        dgv1.Columns(6).HeaderText = "JENIS"
        dgv1.Columns(7).HeaderText = "JUMLAH"
        dgv1.Columns(8).HeaderText = "STATUS PEMBAYARAN"
        dgv1.Columns(9).HeaderText = "ID USER"
    End Sub

    Sub ItemCbGuest()
        Koneksi()
        Try
            Cmd = New MySqlCommand("select nama from tbguest order by id_guest", Conn)
            Rd = Cmd.ExecuteReader
            While Rd.Read
                artis.Items.Add(Rd("nama"))
            End While
        Catch ex As Exception
        End Try
    End Sub

    Private Sub PesanTiket_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call Pesan()
        Call KondisiAwal()
        Call AturGrid()
        Call ItemCbGuest()
        Call AutoNumber()
        Call txId()
    End Sub
    Private Sub btnPesan_Click(sender As Object, e As EventArgs) Handles btnPesan.Click
        If nama.Text = "" Or email.Text = "" Or nohp.Text = "" Or artis.Text = "
                         " Or jenis.Text = "" Or jumlah.Text = "" Or id_pesanan.Text = "" Or statuss.Text = "" Then
            MsgBox("Data belum lengkap")
            id_pesanan.Focus()
        Else
            Cmd = New MySqlCommand("Select * From tbpesanan where id_pesanan='" & id_pesanan.Text & "'", Conn)
            'Rd = Cmd.ExecuteReader
            Rd.Read()
            Rd.Close()

            If Not Rd.HasRows Then
                Dim Simpan As String = "insert into tbpesanan (id_pesanan,nama,noktp,email,nohp,guest,jenis,jumlah,status,id_regis)
                                        values ('" & id_pesanan.Text & "','" & nama.Text & "','" & noktp.Text & "','" & email.Text & "', '" & nohp.Text & "',
                                                '" & artis.Text & "','" & jenis.Text & "', '" & jumlah.Text & "', '" & statuss.Text & "', '" & id_user.Text & "')"
                Cmd = New MySqlCommand(Simpan, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Pemesanan berhasil!", MsgBoxStyle.Information, "Perhatian")
            End If
            Call KondisiAwal()
            id_pesanan.Focus()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Call KondisiAwal()
    End Sub

    Private Sub btnTiket_Click(sender As Object, e As EventArgs) Handles btnTiket.Click
        Try
            Call Koneksi()

            Dim Tiket As String = "select nama,guest,jenis,jumlah,status from tbpesanan 
                                   Where id_pesanan = '" & id_pesanan.Text & "'"
            Cmd = New MySqlCommand(Tiket, Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Rd.HasRows Then
                TampilTiket.lbnama.Text = Rd.Item("nama")
                TampilTiket.lbartis.Text = Rd.Item("guest")
                TampilTiket.lbjenis.Text = Rd.Item("jenis")
                TampilTiket.lbjumlah.Text = Rd.Item("jumlah")
                TampilTiket.lbstatus.Text = Rd.Item("status")
            End If
        Catch ex As Exception
        End Try
        TampilTiket.Show()
        Me.Close()
    End Sub

    Private Sub dgv1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv1.CellClick
        Dim i As Integer
        i = dgv1.CurrentRow.Index

        On Error Resume Next
        id_pesanan.Text = dgv1.Item(0, i).Value
        nama.Text = dgv1.Item(1, i).Value
        noktp.Text = dgv1.Item(2, i).Value
        email.Text = dgv1.Item(3, i).Value
        nohp.Text = dgv1.Item(4, i).Value
        artis.Text = dgv1.Item(5, i).Value
        jenis.Text = dgv1.Item(6, i).Value
        jumlah.Text = dgv1.Item(7, i).Value
        statuss.Text = dgv1.Item(8, i).Value
        id_user.Text = dgv1.Item(9, i).Value
    End Sub

    Private Sub noktp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles noktp.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub kembali_Click(sender As Object, e As EventArgs) Handles kembali.Click
        MenuUser.Show()
        Me.Hide()
    End Sub

    Private Sub nohp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nohp.KeyPress
        If Char.IsNumber(e.KeyChar) OrElse e.KeyChar = vbBack Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub cari_TextChanged(sender As Object, e As EventArgs) Handles cari.TextChanged
        Call Koneksi()
        Cmd = New MySqlCommand("select * from tbpesanan where nama like '%" & cari.Text & "%'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            Call Koneksi()
            Da = New MySqlDataAdapter("select * from tbpesanan where nama like '%" & cari.Text & "%'", Conn)
            Ds = New DataSet
            Da.Fill(Ds, "ketemu")
            dgv1.DataSource = Ds.Tables("ketemu")
            dgv1.ReadOnly = True
        End If
    End Sub

End Class