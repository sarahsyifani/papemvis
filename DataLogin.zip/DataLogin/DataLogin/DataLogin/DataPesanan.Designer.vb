﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DataPesanan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cari = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.username = New System.Windows.Forms.Label()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnUbah = New System.Windows.Forms.Button()
        Me.kembali = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dgv3 = New System.Windows.Forms.DataGridView()
        Me.artis = New System.Windows.Forms.ComboBox()
        Me.nohp = New System.Windows.Forms.TextBox()
        Me.email = New System.Windows.Forms.TextBox()
        Me.nama = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.id_user = New System.Windows.Forms.TextBox()
        Me.noktp = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.statuss = New System.Windows.Forms.TextBox()
        Me.id_pesanan = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.jenis = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.jumlah = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.jumlah, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cari
        '
        Me.cari.BackColor = System.Drawing.Color.BurlyWood
        Me.cari.Location = New System.Drawing.Point(581, 366)
        Me.cari.Margin = New System.Windows.Forms.Padding(2)
        Me.cari.Name = "cari"
        Me.cari.Size = New System.Drawing.Size(272, 20)
        Me.cari.TabIndex = 74
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(525, 361)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 22)
        Me.Label12.TabIndex = 73
        Me.Label12.Text = "Cari"
        '
        'username
        '
        Me.username.AutoSize = True
        Me.username.BackColor = System.Drawing.Color.Transparent
        Me.username.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username.ForeColor = System.Drawing.SystemColors.ControlText
        Me.username.Location = New System.Drawing.Point(567, 35)
        Me.username.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.username.Name = "username"
        Me.username.Size = New System.Drawing.Size(109, 22)
        Me.username.TabIndex = 72
        Me.username.Text = "USERNAME"
        '
        'btnHapus
        '
        Me.btnHapus.BackColor = System.Drawing.Color.BurlyWood
        Me.btnHapus.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHapus.Location = New System.Drawing.Point(784, 397)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(100, 43)
        Me.btnHapus.TabIndex = 71
        Me.btnHapus.Text = "Hapus Data"
        Me.btnHapus.UseVisualStyleBackColor = False
        '
        'btnUbah
        '
        Me.btnUbah.BackColor = System.Drawing.Color.BurlyWood
        Me.btnUbah.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUbah.Location = New System.Drawing.Point(661, 397)
        Me.btnUbah.Name = "btnUbah"
        Me.btnUbah.Size = New System.Drawing.Size(100, 43)
        Me.btnUbah.TabIndex = 70
        Me.btnUbah.Text = "Edit Status Pembayaran"
        Me.btnUbah.UseVisualStyleBackColor = False
        '
        'kembali
        '
        Me.kembali.BackColor = System.Drawing.Color.BurlyWood
        Me.kembali.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.kembali.Location = New System.Drawing.Point(538, 397)
        Me.kembali.Name = "kembali"
        Me.kembali.Size = New System.Drawing.Size(100, 43)
        Me.kembali.TabIndex = 69
        Me.kembali.Text = "Kembali"
        Me.kembali.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(504, 34)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(350, 66)
        Me.Label14.TabIndex = 68
        Me.Label14.Text = "Halo," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Berikut adalah list data pesanan tiket" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'dgv3
        '
        Me.dgv3.BackgroundColor = System.Drawing.Color.BurlyWood
        Me.dgv3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv3.Location = New System.Drawing.Point(480, 96)
        Me.dgv3.Name = "dgv3"
        Me.dgv3.RowHeadersWidth = 62
        Me.dgv3.Size = New System.Drawing.Size(467, 262)
        Me.dgv3.TabIndex = 67
        '
        'artis
        '
        Me.artis.BackColor = System.Drawing.Color.BurlyWood
        Me.artis.Enabled = False
        Me.artis.FormattingEnabled = True
        Me.artis.Items.AddRange(New Object() {""})
        Me.artis.Location = New System.Drawing.Point(200, 286)
        Me.artis.Name = "artis"
        Me.artis.Size = New System.Drawing.Size(143, 21)
        Me.artis.TabIndex = 100
        '
        'nohp
        '
        Me.nohp.BackColor = System.Drawing.Color.BurlyWood
        Me.nohp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nohp.Enabled = False
        Me.nohp.Location = New System.Drawing.Point(200, 249)
        Me.nohp.Name = "nohp"
        Me.nohp.ReadOnly = True
        Me.nohp.Size = New System.Drawing.Size(143, 20)
        Me.nohp.TabIndex = 99
        '
        'email
        '
        Me.email.BackColor = System.Drawing.Color.BurlyWood
        Me.email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.email.Enabled = False
        Me.email.Location = New System.Drawing.Point(200, 211)
        Me.email.Name = "email"
        Me.email.ReadOnly = True
        Me.email.Size = New System.Drawing.Size(143, 20)
        Me.email.TabIndex = 98
        '
        'nama
        '
        Me.nama.BackColor = System.Drawing.Color.BurlyWood
        Me.nama.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nama.Enabled = False
        Me.nama.Location = New System.Drawing.Point(200, 137)
        Me.nama.Name = "nama"
        Me.nama.ReadOnly = True
        Me.nama.Size = New System.Drawing.Size(143, 20)
        Me.nama.TabIndex = 96
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(20, 287)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 20)
        Me.Label5.TabIndex = 95
        Me.Label5.Text = "Guest Star"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(24, 247)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 20)
        Me.Label4.TabIndex = 94
        Me.Label4.Text = "No HP"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(20, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 20)
        Me.Label3.TabIndex = 93
        Me.Label3.Text = "Email"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(20, 135)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 20)
        Me.Label1.TabIndex = 91
        Me.Label1.Text = "Nama Lengkap"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.id_user)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.noktp)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.email)
        Me.GroupBox1.Controls.Add(Me.nohp)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.artis)
        Me.GroupBox1.Controls.Add(Me.statuss)
        Me.GroupBox1.Controls.Add(Me.id_pesanan)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.nama)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.jenis)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.jumlah)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox1.Location = New System.Drawing.Point(46, 15)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(378, 441)
        Me.GroupBox1.TabIndex = 103
        Me.GroupBox1.TabStop = False
        '
        'id_user
        '
        Me.id_user.BackColor = System.Drawing.Color.BurlyWood
        Me.id_user.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.id_user.Enabled = False
        Me.id_user.Location = New System.Drawing.Point(200, 62)
        Me.id_user.Name = "id_user"
        Me.id_user.ReadOnly = True
        Me.id_user.Size = New System.Drawing.Size(143, 20)
        Me.id_user.TabIndex = 104
        '
        'noktp
        '
        Me.noktp.BackColor = System.Drawing.Color.BurlyWood
        Me.noktp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.noktp.Enabled = False
        Me.noktp.Location = New System.Drawing.Point(200, 177)
        Me.noktp.Name = "noktp"
        Me.noktp.ReadOnly = True
        Me.noktp.Size = New System.Drawing.Size(145, 20)
        Me.noktp.TabIndex = 103
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(20, 177)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 20)
        Me.Label2.TabIndex = 102
        Me.Label2.Text = "Nomor KTP"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(24, 62)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(64, 20)
        Me.Label11.TabIndex = 101
        Me.Label11.Text = "ID User"
        '
        'statuss
        '
        Me.statuss.BackColor = System.Drawing.Color.BurlyWood
        Me.statuss.Enabled = False
        Me.statuss.Location = New System.Drawing.Point(202, 401)
        Me.statuss.Name = "statuss"
        Me.statuss.ReadOnly = True
        Me.statuss.Size = New System.Drawing.Size(143, 20)
        Me.statuss.TabIndex = 92
        '
        'id_pesanan
        '
        Me.id_pesanan.BackColor = System.Drawing.Color.BurlyWood
        Me.id_pesanan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.id_pesanan.Enabled = False
        Me.id_pesanan.Location = New System.Drawing.Point(200, 97)
        Me.id_pesanan.Name = "id_pesanan"
        Me.id_pesanan.ReadOnly = True
        Me.id_pesanan.Size = New System.Drawing.Size(143, 20)
        Me.id_pesanan.TabIndex = 91
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(20, 97)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 20)
        Me.Label9.TabIndex = 90
        Me.Label9.Text = "ID Pesanan"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(22, 323)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 20)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Jenis Festival"
        '
        'jenis
        '
        Me.jenis.BackColor = System.Drawing.Color.BurlyWood
        Me.jenis.Enabled = False
        Me.jenis.FormattingEnabled = True
        Me.jenis.Items.AddRange(New Object() {"reguler", "vip"})
        Me.jenis.Location = New System.Drawing.Point(200, 325)
        Me.jenis.Name = "jenis"
        Me.jenis.Size = New System.Drawing.Size(145, 21)
        Me.jenis.TabIndex = 80
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(24, 360)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 20)
        Me.Label7.TabIndex = 73
        Me.Label7.Text = "Jumlah Tiket"
        '
        'jumlah
        '
        Me.jumlah.BackColor = System.Drawing.Color.BurlyWood
        Me.jumlah.Enabled = False
        Me.jumlah.Location = New System.Drawing.Point(202, 363)
        Me.jumlah.Margin = New System.Windows.Forms.Padding(2)
        Me.jumlah.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.jumlah.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.jumlah.Name = "jumlah"
        Me.jumlah.ReadOnly = True
        Me.jumlah.Size = New System.Drawing.Size(141, 20)
        Me.jumlah.TabIndex = 83
        Me.jumlah.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(24, 401)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(149, 20)
        Me.Label10.TabIndex = 86
        Me.Label10.Text = "Status Pembayaran"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(89, 32)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(204, 20)
        Me.Label8.TabIndex = 74
        Me.Label8.Text = "DATA PEMESANAN TIKET"
        '
        'DataPesanan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.bgpolos1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(972, 518)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cari)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.username)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.btnUbah)
        Me.Controls.Add(Me.kembali)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.dgv3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "DataPesanan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DataPesanan"
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.jumlah, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cari As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents username As Label
    Friend WithEvents btnHapus As Button
    Friend WithEvents btnUbah As Button
    Friend WithEvents kembali As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents dgv3 As DataGridView
    Friend WithEvents artis As ComboBox
    Friend WithEvents nohp As TextBox
    Friend WithEvents email As TextBox
    Friend WithEvents nama As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents statuss As TextBox
    Friend WithEvents id_pesanan As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents jenis As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents jumlah As NumericUpDown
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents noktp As TextBox
    Friend WithEvents id_user As TextBox
End Class
