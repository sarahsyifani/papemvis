﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PesanTiket
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.username = New System.Windows.Forms.Label()
        Me.kembali = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.jumlah = New System.Windows.Forms.NumericUpDown()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnPesan = New System.Windows.Forms.Button()
        Me.jenis = New System.Windows.Forms.ComboBox()
        Me.artis = New System.Windows.Forms.ComboBox()
        Me.nohp = New System.Windows.Forms.TextBox()
        Me.email = New System.Windows.Forms.TextBox()
        Me.noktp = New System.Windows.Forms.TextBox()
        Me.nama = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.id_user = New System.Windows.Forms.TextBox()
        Me.statuss = New System.Windows.Forms.ComboBox()
        Me.id_pesanan = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnTiket = New System.Windows.Forms.Button()
        Me.cari = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.jumlah, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'username
        '
        Me.username.AutoSize = True
        Me.username.BackColor = System.Drawing.Color.Transparent
        Me.username.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username.ForeColor = System.Drawing.Color.Black
        Me.username.Location = New System.Drawing.Point(463, 65)
        Me.username.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.username.Name = "username"
        Me.username.Size = New System.Drawing.Size(109, 22)
        Me.username.TabIndex = 96
        Me.username.Text = "USERNAME"
        '
        'kembali
        '
        Me.kembali.BackColor = System.Drawing.Color.BurlyWood
        Me.kembali.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.kembali.Location = New System.Drawing.Point(531, 456)
        Me.kembali.Name = "kembali"
        Me.kembali.Size = New System.Drawing.Size(100, 43)
        Me.kembali.TabIndex = 93
        Me.kembali.Text = "Kembali"
        Me.kembali.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(406, 66)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(475, 44)
        Me.Label14.TabIndex = 92
        Me.Label14.Text = "Halo," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cek apakah terdapat pesanan kamu dibawah ini!" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'dgv1
        '
        Me.dgv1.BackgroundColor = System.Drawing.Color.BurlyWood
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(410, 127)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersWidth = 62
        Me.dgv1.Size = New System.Drawing.Size(482, 262)
        Me.dgv1.TabIndex = 91
        '
        'jumlah
        '
        Me.jumlah.BackColor = System.Drawing.Color.BurlyWood
        Me.jumlah.Location = New System.Drawing.Point(200, 339)
        Me.jumlah.Margin = New System.Windows.Forms.Padding(2)
        Me.jumlah.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.jumlah.Name = "jumlah"
        Me.jumlah.Size = New System.Drawing.Size(141, 20)
        Me.jumlah.TabIndex = 83
        Me.jumlah.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.BurlyWood
        Me.btnClear.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(215, 456)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(100, 43)
        Me.btnClear.TabIndex = 82
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnPesan
        '
        Me.btnPesan.BackColor = System.Drawing.Color.BurlyWood
        Me.btnPesan.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPesan.Location = New System.Drawing.Point(80, 456)
        Me.btnPesan.Name = "btnPesan"
        Me.btnPesan.Size = New System.Drawing.Size(100, 43)
        Me.btnPesan.TabIndex = 81
        Me.btnPesan.Text = "Buat Pesanan"
        Me.btnPesan.UseVisualStyleBackColor = False
        '
        'jenis
        '
        Me.jenis.BackColor = System.Drawing.Color.BurlyWood
        Me.jenis.FormattingEnabled = True
        Me.jenis.Items.AddRange(New Object() {"reguler", "vip"})
        Me.jenis.Location = New System.Drawing.Point(200, 301)
        Me.jenis.Name = "jenis"
        Me.jenis.Size = New System.Drawing.Size(143, 21)
        Me.jenis.TabIndex = 80
        '
        'artis
        '
        Me.artis.BackColor = System.Drawing.Color.BurlyWood
        Me.artis.FormattingEnabled = True
        Me.artis.Items.AddRange(New Object() {""})
        Me.artis.Location = New System.Drawing.Point(200, 260)
        Me.artis.Name = "artis"
        Me.artis.Size = New System.Drawing.Size(143, 21)
        Me.artis.TabIndex = 79
        '
        'nohp
        '
        Me.nohp.BackColor = System.Drawing.Color.BurlyWood
        Me.nohp.Location = New System.Drawing.Point(202, 223)
        Me.nohp.Name = "nohp"
        Me.nohp.Size = New System.Drawing.Size(143, 20)
        Me.nohp.TabIndex = 78
        '
        'email
        '
        Me.email.BackColor = System.Drawing.Color.BurlyWood
        Me.email.Location = New System.Drawing.Point(202, 186)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(143, 20)
        Me.email.TabIndex = 77
        '
        'noktp
        '
        Me.noktp.BackColor = System.Drawing.Color.BurlyWood
        Me.noktp.Location = New System.Drawing.Point(202, 152)
        Me.noktp.Name = "noktp"
        Me.noktp.Size = New System.Drawing.Size(143, 20)
        Me.noktp.TabIndex = 76
        '
        'nama
        '
        Me.nama.BackColor = System.Drawing.Color.BurlyWood
        Me.nama.Location = New System.Drawing.Point(202, 114)
        Me.nama.Name = "nama"
        Me.nama.Size = New System.Drawing.Size(143, 20)
        Me.nama.TabIndex = 75
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(109, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(153, 21)
        Me.Label8.TabIndex = 74
        Me.Label8.Text = "PEMESANAN TIKET"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(22, 336)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(107, 21)
        Me.Label7.TabIndex = 73
        Me.Label7.Text = "Jumlah Tiket"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(20, 299)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(109, 21)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Jenis Festival"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(33, 298)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 21)
        Me.Label5.TabIndex = 71
        Me.Label5.Text = "Guest Star"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(35, 260)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 21)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "No HP"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(33, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 21)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = "Email"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(18, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 21)
        Me.Label2.TabIndex = 68
        Me.Label2.Text = "Nomor KTP"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(18, 114)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 21)
        Me.Label1.TabIndex = 67
        Me.Label1.Text = "Nama Lengkap"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.id_user)
        Me.GroupBox1.Controls.Add(Me.statuss)
        Me.GroupBox1.Controls.Add(Me.id_pesanan)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.jenis)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.jumlah)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.nama)
        Me.GroupBox1.Controls.Add(Me.noktp)
        Me.GroupBox1.Controls.Add(Me.email)
        Me.GroupBox1.Controls.Add(Me.nohp)
        Me.GroupBox1.Controls.Add(Me.artis)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(378, 491)
        Me.GroupBox1.TabIndex = 90
        Me.GroupBox1.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Location = New System.Drawing.Point(22, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(63, 21)
        Me.Label11.TabIndex = 94
        Me.Label11.Text = "ID User"
        '
        'id_user
        '
        Me.id_user.BackColor = System.Drawing.Color.BurlyWood
        Me.id_user.Enabled = False
        Me.id_user.Location = New System.Drawing.Point(202, 43)
        Me.id_user.Name = "id_user"
        Me.id_user.ReadOnly = True
        Me.id_user.Size = New System.Drawing.Size(143, 20)
        Me.id_user.TabIndex = 93
        '
        'statuss
        '
        Me.statuss.BackColor = System.Drawing.Color.BurlyWood
        Me.statuss.FormattingEnabled = True
        Me.statuss.Items.AddRange(New Object() {"Belum Bayar"})
        Me.statuss.Location = New System.Drawing.Point(200, 376)
        Me.statuss.Name = "statuss"
        Me.statuss.Size = New System.Drawing.Size(143, 21)
        Me.statuss.TabIndex = 92
        '
        'id_pesanan
        '
        Me.id_pesanan.BackColor = System.Drawing.Color.BurlyWood
        Me.id_pesanan.Enabled = False
        Me.id_pesanan.Location = New System.Drawing.Point(202, 77)
        Me.id_pesanan.Name = "id_pesanan"
        Me.id_pesanan.ReadOnly = True
        Me.id_pesanan.Size = New System.Drawing.Size(143, 20)
        Me.id_pesanan.TabIndex = 91
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Location = New System.Drawing.Point(20, 77)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 21)
        Me.Label9.TabIndex = 90
        Me.Label9.Text = "ID Pesanan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Location = New System.Drawing.Point(22, 377)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(164, 21)
        Me.Label10.TabIndex = 86
        Me.Label10.Text = "Status Pembayaran"
        '
        'btnTiket
        '
        Me.btnTiket.BackColor = System.Drawing.Color.BurlyWood
        Me.btnTiket.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTiket.Location = New System.Drawing.Point(670, 456)
        Me.btnTiket.Name = "btnTiket"
        Me.btnTiket.Size = New System.Drawing.Size(100, 43)
        Me.btnTiket.TabIndex = 99
        Me.btnTiket.Text = "Lihat Tiket"
        Me.btnTiket.UseVisualStyleBackColor = False
        '
        'cari
        '
        Me.cari.BackColor = System.Drawing.Color.BurlyWood
        Me.cari.Location = New System.Drawing.Point(556, 416)
        Me.cari.Margin = New System.Windows.Forms.Padding(2)
        Me.cari.Name = "cari"
        Me.cari.Size = New System.Drawing.Size(272, 20)
        Me.cari.TabIndex = 101
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(500, 411)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 22)
        Me.Label12.TabIndex = 100
        Me.Label12.Text = "Cari"
        '
        'PesanTiket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.bgpolos1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(921, 541)
        Me.Controls.Add(Me.cari)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnTiket)
        Me.Controls.Add(Me.username)
        Me.Controls.Add(Me.kembali)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnPesan)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "PesanTiket"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PesanTiket"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.jumlah, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents username As Label
    Friend WithEvents kembali As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents jumlah As NumericUpDown
    Friend WithEvents btnClear As Button
    Friend WithEvents btnPesan As Button
    Friend WithEvents jenis As ComboBox
    Friend WithEvents artis As ComboBox
    Friend WithEvents nohp As TextBox
    Friend WithEvents email As TextBox
    Friend WithEvents noktp As TextBox
    Friend WithEvents nama As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label10 As Label
    Friend WithEvents id_pesanan As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents btnTiket As Button
    Friend WithEvents statuss As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents id_user As TextBox
    Friend WithEvents cari As TextBox
    Friend WithEvents Label12 As Label
End Class
