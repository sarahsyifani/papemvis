﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Logout = New System.Windows.Forms.Button()
        Me.pesanan = New System.Windows.Forms.Button()
        Me.guest = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Logout
        '
        Me.Logout.BackColor = System.Drawing.Color.BurlyWood
        Me.Logout.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Logout.Location = New System.Drawing.Point(492, 217)
        Me.Logout.Name = "Logout"
        Me.Logout.Size = New System.Drawing.Size(100, 59)
        Me.Logout.TabIndex = 5
        Me.Logout.Text = "Logout"
        Me.Logout.UseVisualStyleBackColor = False
        '
        'pesanan
        '
        Me.pesanan.BackColor = System.Drawing.Color.BurlyWood
        Me.pesanan.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pesanan.Location = New System.Drawing.Point(195, 217)
        Me.pesanan.Name = "pesanan"
        Me.pesanan.Size = New System.Drawing.Size(120, 59)
        Me.pesanan.TabIndex = 4
        Me.pesanan.Text = "Manajemen Data Pesanan"
        Me.pesanan.UseVisualStyleBackColor = False
        '
        'guest
        '
        Me.guest.BackColor = System.Drawing.Color.BurlyWood
        Me.guest.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.guest.Location = New System.Drawing.Point(342, 217)
        Me.guest.Name = "guest"
        Me.guest.Size = New System.Drawing.Size(123, 59)
        Me.guest.TabIndex = 6
        Me.guest.Text = "Manajemen Data Guest Star"
        Me.guest.UseVisualStyleBackColor = False
        '
        'MenuAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.menu
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.guest)
        Me.Controls.Add(Me.Logout)
        Me.Controls.Add(Me.pesanan)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MenuAdmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MenuAdmin"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Logout As Button
    Friend WithEvents pesanan As Button
    Friend WithEvents guest As Button
End Class
