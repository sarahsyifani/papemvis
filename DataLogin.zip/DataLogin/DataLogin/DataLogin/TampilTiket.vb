﻿Public Class TampilTiket
    Private Sub Kembali_Click(sender As Object, e As EventArgs) Handles Kembali.Click
        PesanTiket.Show()
        Me.Close()
    End Sub

    Private Sub Logout_Click(sender As Object, e As EventArgs) Handles Logout.Click
        MenuAwal.Show()
        Me.Close()
    End Sub

    Private Sub TampilTiket_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class