﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoginAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.checkboxTampil = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnExitOut = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnLoginAdmin = New System.Windows.Forms.Button()
        Me.txtboxPasswordAdmin = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtboxUsernameAdmin = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Bisque
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.checkboxTampil)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.btnExitOut)
        Me.Panel2.Controls.Add(Me.btnCancel)
        Me.Panel2.Controls.Add(Me.btnLoginAdmin)
        Me.Panel2.Controls.Add(Me.txtboxPasswordAdmin)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.txtboxUsernameAdmin)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(102, 87)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(574, 331)
        Me.Panel2.TabIndex = 5
        '
        'checkboxTampil
        '
        Me.checkboxTampil.AutoSize = True
        Me.checkboxTampil.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkboxTampil.Location = New System.Drawing.Point(80, 212)
        Me.checkboxTampil.Margin = New System.Windows.Forms.Padding(2)
        Me.checkboxTampil.Name = "checkboxTampil"
        Me.checkboxTampil.Size = New System.Drawing.Size(135, 20)
        Me.checkboxTampil.TabIndex = 11
        Me.checkboxTampil.Text = "Tampilkan Password"
        Me.checkboxTampil.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(101, 41)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(357, 20)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Inputkan Username dan Password di Bawah Ini!"
        '
        'btnExitOut
        '
        Me.btnExitOut.BackColor = System.Drawing.Color.BurlyWood
        Me.btnExitOut.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExitOut.Location = New System.Drawing.Point(329, 261)
        Me.btnExitOut.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExitOut.Name = "btnExitOut"
        Me.btnExitOut.Size = New System.Drawing.Size(87, 31)
        Me.btnExitOut.TabIndex = 8
        Me.btnExitOut.Text = "Kembali"
        Me.btnExitOut.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.BurlyWood
        Me.btnCancel.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(237, 261)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(87, 31)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnLoginAdmin
        '
        Me.btnLoginAdmin.BackColor = System.Drawing.Color.BurlyWood
        Me.btnLoginAdmin.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoginAdmin.Location = New System.Drawing.Point(146, 261)
        Me.btnLoginAdmin.Margin = New System.Windows.Forms.Padding(2)
        Me.btnLoginAdmin.Name = "btnLoginAdmin"
        Me.btnLoginAdmin.Size = New System.Drawing.Size(87, 31)
        Me.btnLoginAdmin.TabIndex = 6
        Me.btnLoginAdmin.Text = "Login"
        Me.btnLoginAdmin.UseVisualStyleBackColor = False
        '
        'txtboxPasswordAdmin
        '
        Me.txtboxPasswordAdmin.BackColor = System.Drawing.Color.BurlyWood
        Me.txtboxPasswordAdmin.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtboxPasswordAdmin.Location = New System.Drawing.Point(80, 182)
        Me.txtboxPasswordAdmin.Margin = New System.Windows.Forms.Padding(2)
        Me.txtboxPasswordAdmin.Name = "txtboxPasswordAdmin"
        Me.txtboxPasswordAdmin.Size = New System.Drawing.Size(413, 22)
        Me.txtboxPasswordAdmin.TabIndex = 5
        Me.txtboxPasswordAdmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtboxPasswordAdmin.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(221, 152)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Input Password"
        '
        'txtboxUsernameAdmin
        '
        Me.txtboxUsernameAdmin.BackColor = System.Drawing.Color.BurlyWood
        Me.txtboxUsernameAdmin.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtboxUsernameAdmin.Location = New System.Drawing.Point(80, 115)
        Me.txtboxUsernameAdmin.Margin = New System.Windows.Forms.Padding(2)
        Me.txtboxUsernameAdmin.Name = "txtboxUsernameAdmin"
        Me.txtboxUsernameAdmin.Size = New System.Drawing.Size(413, 22)
        Me.txtboxUsernameAdmin.TabIndex = 3
        Me.txtboxUsernameAdmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(221, 82)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Input Username"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(303, 53)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(164, 22)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Please Login First!"
        '
        'LoginAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.bgpolos1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(778, 470)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "LoginAdmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LoginAdmin"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents checkboxTampil As CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnExitOut As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnLoginAdmin As Button
    Friend WithEvents txtboxPasswordAdmin As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtboxUsernameAdmin As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
