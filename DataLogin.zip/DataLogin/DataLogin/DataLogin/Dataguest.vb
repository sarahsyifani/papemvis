﻿Imports MySql.Data.MySqlClient

Public Class DataGuest
    Sub Kosong()
        id_guest.Clear()
        nama.Clear()
    End Sub
    Sub Isi()
        id_guest.Clear()
        id_guest.Focus()
        nama.Clear()
        nama.Focus()
    End Sub
    Sub Artis()
        Da = New MySqlDataAdapter("Select * From tbguest", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbguest")
        dgv2.DataSource = Ds.Tables("tbguest")
        dgv2.Refresh()
    End Sub
    Sub AturGrid()
        dgv2.Columns(0).Width = 100
        dgv2.Columns(1).Width = 100

        dgv2.Columns(0).HeaderText = "ID GUEST STAR"
        dgv2.Columns(1).HeaderText = "GUEST STAR"
    End Sub
    Sub AutoNumber()
        Call Koneksi()
        Cmd = New MySqlCommand("select max(id_guest) from tbguest", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        On Error GoTo Err
        If Rd.HasRows Then
            id_guest.Text = Format(Val(Rd.Item(0)) + 1, "0")
        End If
        Exit Sub
Err:
        id_guest.Text = "1"
    End Sub
    Private Sub MenuAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call Artis()
        Call Kosong()
        Call AturGrid()
        Call AutoNumber()
    End Sub
    Private Sub dgv2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv2.CellContentClick
        Dim i As Integer
        i = Me.dgv2.CurrentRow.Index
        With dgv2.Rows.Item(i)
            Me.id_guest.Text = .Cells(0).Value
            Me.nama.Text = .Cells(1).Value
        End With
    End Sub
    Private Sub btnTambah_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        If id_guest.Text = "" Or nama.Text = "" Then
            MsgBox("Data belum lengkap")
            id_guest.Focus()
            'Exit Sub
        Else
            Cmd = New MySqlCommand("Select * From tbguest where id_guest='" & id_guest.Text & "'", Conn)
            'Rd = Cmd.ExecuteReader
            Rd.Read()
            Rd.Close()
            If Not Rd.HasRows Then
                Dim Simpan As String = "insert into tbguest (id_guest,nama)
                                        values ('" & id_guest.Text & "','" & nama.Text & "')"
                Cmd = New MySqlCommand(Simpan, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Simpan data sukses......", MsgBoxStyle.Information, "Perhatian")
            End If
            Call Artis()
            Call Kosong()
            id_guest.Focus()
        End If
    End Sub

    Private Sub btnUbah_Click(sender As Object, e As EventArgs) Handles btnUbah.Click
        If id_guest.Text = "" Or nama.Text = "" Then
            MsgBox("Data belum lengkap")
            id_guest.Focus()
            Exit Sub
        Else
            Dim Ubah As String = "Update tbguest set id_guest = '" & id_guest.Text & "', 
                                                     nama ='" & nama.Text & "'
                                                     where id_guest = '" & id_guest.Text & "'"
            Cmd = New MySqlCommand(Ubah, Conn)
            Cmd.ExecuteNonQuery()
            MessageBox.Show("Data Sudah Diubah", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call Artis()
            Call Kosong()
            id_guest.Focus()
        End If
    End Sub
    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        If id_guest.Text = "" Then
            MsgBox("Pilih data yang ingin dihapus!")
            id_guest.Focus()
            Exit Sub
        Else
            If MessageBox.Show("Yakin akan menghapus Data Guest Star " & id_guest.Text &
                           " ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Cmd = New MySqlCommand("Delete From tbguest Where id_guest = '" & id_guest.Text & "'", Conn)
                Cmd.ExecuteNonQuery()
                Call Kosong()
                Call Artis()
            Else
                Call Kosong()
            End If
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Call Kosong()
    End Sub

    Private Sub kembali_Click(sender As Object, e As EventArgs) Handles kembali.Click
        MenuAdmin.Show()
        Me.Close()
    End Sub

    Private Sub dgv2_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv2.CellClick
        Dim i As Integer
        i = dgv2.CurrentRow.Index

        On Error Resume Next
        id_guest.Text = dgv2.Item(0, i).Value
        nama.Text = dgv2.Item(1, i).Value
    End Sub

    Private Sub cari_TextChanged(sender As Object, e As EventArgs) Handles cari.TextChanged
        Call Koneksi()
        Cmd = New MySqlCommand("select * from tbguest where nama like '%" & cari.Text & "%'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            Call Koneksi()
            Da = New MySqlDataAdapter("select * from tbguest where nama like '%" & cari.Text & "%'", Conn)
            Ds = New DataSet
            Da.Fill(Ds, "ketemu")
            dgv2.DataSource = Ds.Tables("ketemu")
            dgv2.ReadOnly = True
        End If
    End Sub
End Class