﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class DataPesanan
    Sub Pesan()
        Da = New MySqlDataAdapter("Select * From tbpesanan", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbpesanan")
        dgv3.DataSource = Ds.Tables("tbpesanan")
        dgv3.Refresh()
    End Sub

    Sub AturGrid()
        dgv3.Columns(0).Width = 60
        dgv3.Columns(1).Width = 100
        dgv3.Columns(2).Width = 100
        dgv3.Columns(3).Width = 100
        dgv3.Columns(4).Width = 100
        dgv3.Columns(5).Width = 100
        dgv3.Columns(6).Width = 100
        dgv3.Columns(7).Width = 100
        dgv3.Columns(8).Width = 100
        dgv3.Columns(8).Width = 100

        dgv3.Columns(0).HeaderText = "ID PESANAN"
        dgv3.Columns(1).HeaderText = "NAMA"
        dgv3.Columns(2).HeaderText = "NO KTP"
        dgv3.Columns(3).HeaderText = "EMAIL"
        dgv3.Columns(4).HeaderText = "NO HP"
        dgv3.Columns(5).HeaderText = "GUEST STAR"
        dgv3.Columns(6).HeaderText = "JENIS"
        dgv3.Columns(7).HeaderText = "JUMLAH"
        dgv3.Columns(8).HeaderText = "STATUS PEMBAYARAN"
        dgv3.Columns(9).HeaderText = "ID USER"
    End Sub

    Private Sub dgv3_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv3.CellClick
        Dim i As Integer
        i = dgv3.CurrentRow.Index

        On Error Resume Next
        id_pesanan.Text = dgv3.Item(0, i).Value
        nama.Text = dgv3.Item(1, i).Value
        noktp.Text = dgv3.Item(2, i).Value
        email.Text = dgv3.Item(3, i).Value
        nohp.Text = dgv3.Item(4, i).Value
        artis.Text = dgv3.Item(5, i).Value
        jenis.Text = dgv3.Item(6, i).Value
        jumlah.Text = dgv3.Item(7, i).Value
        statuss.Text = dgv3.Item(8, i).Value
        id_user.Text = dgv3.Item(9, i).Value
    End Sub
    Private Sub kembali_Click(sender As Object, e As EventArgs) Handles kembali.Click
        MenuAdmin.Show()
        Me.Close()
    End Sub

    Private Sub btnUbah_Click(sender As Object, e As EventArgs) Handles btnUbah.Click
        Dim i As Integer
        i = dgv3.CurrentRow.Index
        If id_pesanan.Text = "" Then
            MsgBox("Pilih data yang ingin diubah!")
        Else
            If MessageBox.Show("Yakin ingin mengubah status pemesanan " & id_pesanan.Text &
                           " ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Cmd = New MySqlCommand("Update tbpesanan set status = '" & "Sudah Bayar" & "'where id_pesanan='" & id_pesanan.Text & "'", Conn)
                Cmd.ExecuteNonQuery()
                Call Pesan()
            Else

            End If
        End If
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        If id_pesanan.Text = "" Then
            MsgBox("Pilih data yang ingin dihapus!")
        Else
            If MessageBox.Show("Yakin ingin menghapus data pemesanan " & id_pesanan.Text &
                           " ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Cmd = New MySqlCommand("Delete From tbpesanan Where id_pesanan = '" & id_pesanan.Text & "'", Conn)
                Cmd.ExecuteNonQuery()
                Call Pesan()
            Else

            End If
        End If
    End Sub

    Private Sub DataPesanan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call Pesan()
        Call AturGrid()
    End Sub

    Private Sub cari_TextChanged(sender As Object, e As EventArgs) Handles cari.TextChanged
        Call Koneksi()
        Cmd = New MySqlCommand("select * from tbpesanan where nama like '%" & cari.Text & "%'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            Call Koneksi()
            Da = New MySqlDataAdapter("select * from tbpesanan where nama like '%" & cari.Text & "%'", Conn)
            Ds = New DataSet
            Da.Fill(Ds, "ketemu")
            dgv3.DataSource = Ds.Tables("ketemu")
            dgv3.ReadOnly = True
        End If
    End Sub
End Class