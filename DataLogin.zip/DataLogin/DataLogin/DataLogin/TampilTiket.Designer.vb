﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TampilTiket
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lbjenis = New System.Windows.Forms.Label()
        Me.lbartis = New System.Windows.Forms.Label()
        Me.lbnama = New System.Windows.Forms.Label()
        Me.lbjumlah = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Kembali = New System.Windows.Forms.Button()
        Me.Logout = New System.Windows.Forms.Button()
        Me.lbstatus = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label1.Location = New System.Drawing.Point(248, 220)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nama Lengkap"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label6.Location = New System.Drawing.Point(248, 307)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(109, 21)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Jenis Festival"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label5.Location = New System.Drawing.Point(248, 260)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 21)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Guest Star"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label3.Location = New System.Drawing.Point(248, 307)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 21)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Jenis Festival"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label4.Location = New System.Drawing.Point(248, 260)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 21)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Guest Star"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label8.Location = New System.Drawing.Point(248, 220)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(131, 21)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Nama Lengkap"
        '
        'lbjenis
        '
        Me.lbjenis.AutoSize = True
        Me.lbjenis.BackColor = System.Drawing.Color.Transparent
        Me.lbjenis.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbjenis.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lbjenis.Location = New System.Drawing.Point(427, 307)
        Me.lbjenis.Name = "lbjenis"
        Me.lbjenis.Size = New System.Drawing.Size(109, 21)
        Me.lbjenis.TabIndex = 16
        Me.lbjenis.Text = "Jenis Festival"
        '
        'lbartis
        '
        Me.lbartis.AutoSize = True
        Me.lbartis.BackColor = System.Drawing.Color.Transparent
        Me.lbartis.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbartis.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lbartis.Location = New System.Drawing.Point(427, 260)
        Me.lbartis.Name = "lbartis"
        Me.lbartis.Size = New System.Drawing.Size(92, 21)
        Me.lbartis.TabIndex = 15
        Me.lbartis.Text = "Guest Star"
        '
        'lbnama
        '
        Me.lbnama.AutoSize = True
        Me.lbnama.BackColor = System.Drawing.Color.Transparent
        Me.lbnama.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbnama.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lbnama.Location = New System.Drawing.Point(427, 220)
        Me.lbnama.Name = "lbnama"
        Me.lbnama.Size = New System.Drawing.Size(131, 21)
        Me.lbnama.TabIndex = 14
        Me.lbnama.Text = "Nama Lengkap"
        '
        'lbjumlah
        '
        Me.lbjumlah.AutoSize = True
        Me.lbjumlah.BackColor = System.Drawing.Color.Transparent
        Me.lbjumlah.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbjumlah.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lbjumlah.Location = New System.Drawing.Point(430, 350)
        Me.lbjumlah.Name = "lbjumlah"
        Me.lbjumlah.Size = New System.Drawing.Size(107, 21)
        Me.lbjumlah.TabIndex = 23
        Me.lbjumlah.Text = "Jumlah Tiket"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label15.Location = New System.Drawing.Point(251, 350)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(107, 21)
        Me.Label15.TabIndex = 21
        Me.Label15.Text = "Jumlah Tiket"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label17.Location = New System.Drawing.Point(251, 350)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(107, 21)
        Me.Label17.TabIndex = 19
        Me.Label17.Text = "Jumlah Tiket"
        '
        'Kembali
        '
        Me.Kembali.BackColor = System.Drawing.Color.BurlyWood
        Me.Kembali.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Kembali.Location = New System.Drawing.Point(280, 430)
        Me.Kembali.Name = "Kembali"
        Me.Kembali.Size = New System.Drawing.Size(100, 43)
        Me.Kembali.TabIndex = 25
        Me.Kembali.Text = "Kembali Ke Menu"
        Me.Kembali.UseVisualStyleBackColor = False
        '
        'Logout
        '
        Me.Logout.BackColor = System.Drawing.Color.BurlyWood
        Me.Logout.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Logout.Location = New System.Drawing.Point(401, 430)
        Me.Logout.Name = "Logout"
        Me.Logout.Size = New System.Drawing.Size(100, 43)
        Me.Logout.TabIndex = 24
        Me.Logout.Text = "Logout"
        Me.Logout.UseVisualStyleBackColor = False
        '
        'lbstatus
        '
        Me.lbstatus.AutoSize = True
        Me.lbstatus.BackColor = System.Drawing.Color.Transparent
        Me.lbstatus.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbstatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lbstatus.Location = New System.Drawing.Point(430, 390)
        Me.lbstatus.Name = "lbstatus"
        Me.lbstatus.Size = New System.Drawing.Size(59, 21)
        Me.lbstatus.TabIndex = 28
        Me.lbstatus.Text = "Status"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label20.Location = New System.Drawing.Point(251, 390)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(164, 21)
        Me.Label20.TabIndex = 27
        Me.Label20.Text = "Status Pembayaran"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label21.Location = New System.Drawing.Point(251, 390)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(107, 21)
        Me.Label21.TabIndex = 26
        Me.Label21.Text = "Jumlah Tiket"
        '
        'TampilTiket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.tiket1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(761, 485)
        Me.Controls.Add(Me.lbstatus)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Kembali)
        Me.Controls.Add(Me.Logout)
        Me.Controls.Add(Me.lbjumlah)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.lbjenis)
        Me.Controls.Add(Me.lbartis)
        Me.Controls.Add(Me.lbnama)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "TampilTiket"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TampilTiket"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lbjenis As Label
    Friend WithEvents lbartis As Label
    Friend WithEvents lbnama As Label
    Friend WithEvents lbjumlah As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Kembali As Button
    Friend WithEvents Logout As Button
    Friend WithEvents lbstatus As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
End Class
