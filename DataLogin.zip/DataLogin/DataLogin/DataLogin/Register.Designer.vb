﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtboxPassword = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checkboxTampil = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.linkLoginBack = New System.Windows.Forms.LinkLabel()
        Me.btnLoginFirst = New System.Windows.Forms.Button()
        Me.txtboxUsername = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtboxNama = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Bisque
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.txtboxPassword)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.checkboxTampil)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.linkLoginBack)
        Me.Panel2.Controls.Add(Me.btnLoginFirst)
        Me.Panel2.Controls.Add(Me.txtboxUsername)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.txtboxNama)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(91, 78)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(574, 331)
        Me.Panel2.TabIndex = 3
        '
        'txtboxPassword
        '
        Me.txtboxPassword.BackColor = System.Drawing.Color.BurlyWood
        Me.txtboxPassword.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtboxPassword.Location = New System.Drawing.Point(80, 211)
        Me.txtboxPassword.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtboxPassword.Name = "txtboxPassword"
        Me.txtboxPassword.Size = New System.Drawing.Size(413, 22)
        Me.txtboxPassword.TabIndex = 13
        Me.txtboxPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtboxPassword.UseSystemPasswordChar = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(187, 185)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(195, 20)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Masukkan Password Baru"
        '
        'checkboxTampil
        '
        Me.checkboxTampil.AutoSize = True
        Me.checkboxTampil.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkboxTampil.Location = New System.Drawing.Point(80, 240)
        Me.checkboxTampil.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkboxTampil.Name = "checkboxTampil"
        Me.checkboxTampil.Size = New System.Drawing.Size(135, 20)
        Me.checkboxTampil.TabIndex = 11
        Me.checkboxTampil.Text = "Tampilkan Password"
        Me.checkboxTampil.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(109, 33)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(354, 20)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Inputkan Nama Dan Data Lainnya di Bawah Ini!"
        '
        'linkLoginBack
        '
        Me.linkLoginBack.ActiveLinkColor = System.Drawing.Color.PaleGreen
        Me.linkLoginBack.AutoSize = True
        Me.linkLoginBack.BackColor = System.Drawing.Color.Transparent
        Me.linkLoginBack.DisabledLinkColor = System.Drawing.Color.Black
        Me.linkLoginBack.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.linkLoginBack.LinkColor = System.Drawing.SystemColors.WindowText
        Me.linkLoginBack.Location = New System.Drawing.Point(137, 294)
        Me.linkLoginBack.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.linkLoginBack.Name = "linkLoginBack"
        Me.linkLoginBack.Size = New System.Drawing.Size(322, 17)
        Me.linkLoginBack.TabIndex = 9
        Me.linkLoginBack.TabStop = True
        Me.linkLoginBack.Text = "Sudah Regist Akun? Jika Sudah Kembali ke Login"
        Me.linkLoginBack.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnLoginFirst
        '
        Me.btnLoginFirst.BackColor = System.Drawing.Color.BurlyWood
        Me.btnLoginFirst.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoginFirst.Location = New System.Drawing.Point(249, 252)
        Me.btnLoginFirst.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnLoginFirst.Name = "btnLoginFirst"
        Me.btnLoginFirst.Size = New System.Drawing.Size(87, 31)
        Me.btnLoginFirst.TabIndex = 6
        Me.btnLoginFirst.Text = "Register"
        Me.btnLoginFirst.UseVisualStyleBackColor = False
        '
        'txtboxUsername
        '
        Me.txtboxUsername.BackColor = System.Drawing.Color.BurlyWood
        Me.txtboxUsername.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtboxUsername.Location = New System.Drawing.Point(80, 155)
        Me.txtboxUsername.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtboxUsername.Name = "txtboxUsername"
        Me.txtboxUsername.Size = New System.Drawing.Size(413, 22)
        Me.txtboxUsername.TabIndex = 5
        Me.txtboxUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(184, 131)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(199, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Masukkan Username Baru"
        '
        'txtboxNama
        '
        Me.txtboxNama.BackColor = System.Drawing.Color.BurlyWood
        Me.txtboxNama.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtboxNama.Location = New System.Drawing.Point(80, 96)
        Me.txtboxNama.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtboxNama.Name = "txtboxNama"
        Me.txtboxNama.Size = New System.Drawing.Size(413, 22)
        Me.txtboxNama.TabIndex = 3
        Me.txtboxNama.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(219, 71)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Masukkan Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label1.Location = New System.Drawing.Point(293, 44)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(187, 22)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Please Register First!"
        '
        'Register
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = Global.DataLogin.My.Resources.Resources.bgpolos1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(752, 461)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Register"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Register"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents txtboxPassword As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents checkboxTampil As CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents linkLoginBack As LinkLabel
    Friend WithEvents btnLoginFirst As Button
    Friend WithEvents txtboxUsername As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtboxNama As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
