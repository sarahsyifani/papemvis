﻿Imports System.Data.SqlClient
Imports Microsoft.Win32
Imports MySql.Data.MySqlClient

Public Class LoginAdmin

    Private Sub LoginAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Sistem Penjualan Tiket Konser"
        'Panggil Koneksi
        Koneksi()
    End Sub
    Private Sub checkboxTampil_CheckedChanged_1(sender As Object, e As EventArgs) Handles checkboxTampil.CheckedChanged
        'Tampilkan Password yang tersembunyi
        'Show Password
        If txtboxPasswordAdmin.UseSystemPasswordChar = True Then
            'Hide
            txtboxPasswordAdmin.UseSystemPasswordChar = False
        Else
            'Show
            txtboxPasswordAdmin.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnLoginAdmin_Click(sender As Object, e As EventArgs) Handles btnLoginAdmin.Click
        Cmd = New MySqlCommand("Select * From tbadmin Where username = '" & txtboxUsernameAdmin.Text & "' and password = '" & txtboxPasswordAdmin.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            Me.Visible = False
            DataGuest.username.Text = txtboxUsernameAdmin.Text
            DataPesanan.username.Text = txtboxUsernameAdmin.Text
            MenuAdmin.Show()
            Me.Close()
            Rd.Close()

        ElseIf Not Rd.HasRows Then
            Rd.Close()
            MessageBox.Show("Periksa kembali username dan password!, WARNING, MessageBoxButtons.OK, MessageBoxIcon.Error")
            txtboxUsernameAdmin.Focus()
            txtboxPasswordAdmin.Text = ""
            txtboxPasswordAdmin.Text = ""
        End If


        'Cmd = New MySqlCommand
        'Cmd.Connection = Conn
        'Str = "SELECT * FROM tbadmin WHERE username = ' " & txtboxUsernameAdmin.Text & " ' AND password = ' " & txtboxPasswordAdmin.Text & " '  "
        'Da = New MySqlDataAdapter(Str, Conn)
        'DT = New DataTable()
        ''Data Table System
        'Try
        '    Da.Fill(DT)
        '    'Sistem
        '    If DT.Rows.Count <= 0 Then
        '        MsgBox("Sorry! Login Anda Gagal!", vbInformation)
        '    Else
        '        MenuAdmin.Show()
        '        Me.Close()
        '    End If
        'Catch ex As Exception
        '    MessageBox.Show("Error : " & ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try
    End Sub

    Private Sub btnCancel_Click_1(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Menggunakan Fungsi Clear untuk menghapus
        txtboxUsernameAdmin.Clear()
        txtboxPasswordAdmin.Clear()
    End Sub

    Private Sub btnExitOut_Click_1(sender As Object, e As EventArgs) Handles btnExitOut.Click
        MenuAwal.Show()
        Me.Close()
    End Sub
End Class