﻿Imports MySql.Data.MySqlClient

Public Class Register

    Private Sub Register_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Panggil Koneksi
        Koneksi()
    End Sub

    Private Sub linkLoginBack_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        'Panggil Kembali Form Login
        MenuAdmin.Show()
        Me.Hide()
    End Sub

    Private Sub btnLoginFirst_Click(sender As Object, e As EventArgs)
        'In
        Cmd = New MySqlCommand
        Cmd.Connection = Conn
        Str = "INSERT INTO tbregis VALUES (NULL, ' " & txtboxNama.Text & " ', ' " & txtboxUsername.Text & " ' , ' " & txtboxPassword.Text & " ') "
        Cmd.CommandText = Str

        'Tampilan Form Register
        Try
            Cmd.ExecuteNonQuery()
            MsgBox("Registrasi Sukses! Silahkan pindah ke Login! Thank You!", vbInformation)
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub checkboxTampil_CheckedChanged(sender As Object, e As EventArgs)
        'Show Password
        If txtboxPassword.UseSystemPasswordChar = True Then
            'Hide
            txtboxPassword.UseSystemPasswordChar = False
        Else
            'Show
            txtboxPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub linkLoginBack_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles linkLoginBack.LinkClicked
        DataLogin.Show()
        Me.Close()
    End Sub

    Private Sub checkboxTampil_CheckedChanged_1(sender As Object, e As EventArgs) Handles checkboxTampil.CheckedChanged
        'Show Password
        If txtboxPassword.UseSystemPasswordChar = True Then
            'Hide
            txtboxPassword.UseSystemPasswordChar = False
        Else
            'Show
            txtboxPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnLoginFirst_Click_1(sender As Object, e As EventArgs) Handles btnLoginFirst.Click
        'In
        Cmd = New MySqlCommand
        Cmd.Connection = Conn
        Str = "INSERT INTO tbregis VALUES (NULL, ' " & txtboxNama.Text & " ', ' " & txtboxUsername.Text & " ' , ' " & txtboxPassword.Text & " ') "
        Cmd.CommandText = Str

        'Tampilan Form Register
        Try
            Cmd.ExecuteNonQuery()
            MsgBox("Registrasi Sukses! Silahkan pindah ke Login! Thank You!", vbInformation)
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class