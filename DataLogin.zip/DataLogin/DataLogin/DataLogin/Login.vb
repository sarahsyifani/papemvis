﻿Imports System.Data.SqlClient
Imports Microsoft.Win32
Imports MySql.Data.MySqlClient

Public Class DataLogin
    Private Sub btnCancel_Click(sender As Object, e As EventArgs)
        'Menggunakan Fungsi Clear untuk menghapus
        txtboxUsername.Clear()
        txtboxPassword.Clear()
    End Sub

    Private Sub btnExitOut_Click(sender As Object, e As EventArgs)
        'Untuk mengakhiri program langsung
        End
    End Sub

    Private Sub checkboxTampil_CheckedChanged(sender As Object, e As EventArgs)
        'Tampilkan Password yang tersembunyi
        'Show Password
        If txtboxPassword.UseSystemPasswordChar = True Then
            'Hide
            txtboxPassword.UseSystemPasswordChar = False
        Else
            'Show
            txtboxPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub DataLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Sistem Penjualan Tiket Konser"
        'Panggil Koneksi
        Koneksi()
    End Sub

    Private Sub btnLoginFirst_Click(sender As Object, e As EventArgs)
        'Sistem Login Setelah Register
        Cmd = New MySqlCommand
        Cmd.Connection = Conn
        Str = "SELECT * FROM tbregis WHERE username = ' " & txtboxUsername.Text & " ' AND password = ' " & txtboxPassword.Text & " '  "
        Da = New MySqlDataAdapter(Str, Conn)
        DT = New DataTable()
        'Data Table System
        Try
            Da.Fill(DT)
            'Sistem
            If DT.Rows.Count <= 0 Then
                MsgBox("Sorry! Login Anda Gagal!", vbInformation)
            Else
                TampilanMenu.Show()
                Me.Hide()
            End If
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        Register.Show()
        Me.Hide()
    End Sub
End Class